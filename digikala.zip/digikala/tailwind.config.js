/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./build/*.html'],
  theme: {
   
   fontSize : {
    size1: '11px',
    size2: '15px',
    size3: '13px',
    size4: '20px',
    size5: '12px',
    size6: '12px',
    size7: '32px',
    size8: '14px',
    size9: '23px',
   }
  },
  plugins: [],
}


